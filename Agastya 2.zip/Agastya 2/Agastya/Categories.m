//
//  Categories.m
//  Thobi
//
//  Created by Asaraa on 5/24/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import "Categories.h"
#import "SWRevealViewController.h"

@interface Categories ()<SWRevealViewControllerDelegate>
{
    NSArray *arrayTitles;
    NSArray *arrayTitles1;
    NSArray *arrCategoryImage;
    UILabel *lbl1;
    UILabel *lbl2;
}


@end
@implementation Categories

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    arrCategoryImage = [[NSArray alloc] initWithObjects:@"01", @"02", @"03", @"04",@"05",@"06",@"03", @"01", nil];
    
    arrayTitles = [[NSArray alloc] initWithObjects:@"9999/-", @"4999/-", @"5999/-", @"8999/-",@"9999/-", @"4999/-", @"5999/-", @"8999/-", nil];
    arrayTitles1 = [[NSArray alloc] initWithObjects:@"1500", @"3500", @"4500", @"6500", @"7500", @"2500", @"3500", @"5500", nil];
}


-(void)viewWillAppear:(BOOL)animated
{
 
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationItem.title = @"";
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [arrayTitles count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    
    UIImageView *imgViewProduct = (UIImageView *)[cell viewWithTag:10];
    
    imgViewProduct.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",arrCategoryImage[indexPath.row]]];
    
    UILabel *lblProductName = (UILabel *)[cell viewWithTag:20];
    lblProductName.text = [arrayTitles objectAtIndex:indexPath.row];
    
    UILabel *lblProductName1 = (UILabel *)[cell viewWithTag:30];
    lblProductName1.text = [arrayTitles1 objectAtIndex:indexPath.row];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0){
        
    }
    
    else{
        
    }
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // Adjust cell size for orientation
    
    NSLog(@"_collectionView.frame.size.height/2 = %f",_collectionView.frame.size.height);
    return CGSizeMake([UIScreen mainScreen].bounds.size.width/2 - 20, _collectionView.frame.size.height/2 - 20);
    
}

- (IBAction)backBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];

}

@end
