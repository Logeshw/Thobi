//
//  OrderDetail.m
//  Agastya
//
//  Created by Asaraa on 5/16/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import "OrderDetail.h"
#import "SWRevealViewController.h"

@implementation OrderDetail
- (IBAction)backBtn:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
