//
//  ProfileViewController.m
//  Agastya
//
//  Created by Asaraa on 5/24/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import "ProfileViewController.h"

@implementation ProfileViewController

- (IBAction)backBtn:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];
}

@end
