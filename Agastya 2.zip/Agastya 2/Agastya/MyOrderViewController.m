//S//  MyOrderViewController.m
//  Agastya
//
//  Created by Asaraa on 5/15/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import "MyOrderViewController.h"
#import "SWRevealViewController.h"

@implementation MyOrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    SWRevealViewController *revealViewController = self.revealViewController;
    self.revealViewController.delegate=self;
    if ( revealViewController )
    {
        // self.revealViewController.rightViewRevealWidth = 150;
        [self.menuButton setTarget: self.revealViewController];
        [self.menuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }

}
- (IBAction)Btn2:(id)sender {
    [self performSegueWithIdentifier:@"toOrderDetail" sender:nil];
}
- (IBAction)Btn1:(id)sender {
    [self performSegueWithIdentifier:@"toOrderDetail" sender:nil];
}


- (IBAction)homeBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];
}
- (IBAction)favouriteBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toFavourite = [story instantiateViewControllerWithIdentifier:@"Favourite"];
    [self.navigationController pushViewController:toFavourite animated:YES];
}

- (IBAction)locationBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toLocation = [story instantiateViewControllerWithIdentifier:@"LocationViewController"];
    [self.navigationController pushViewController:toLocation animated:YES];
}

- (IBAction)profileBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toProfile = [story instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    [self.navigationController pushViewController:toProfile animated:YES];
}

@end
