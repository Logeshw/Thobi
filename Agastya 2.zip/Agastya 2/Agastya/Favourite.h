//
//  Favourite.h
//  Agastya
//
//  Created by Asaraa on 5/15/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Favourite : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate>


@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
