//
//  RegisterViewController.h
//  Agastya
//
//  Created by Dipin on 04/05/16.
//  Copyright © 2016 Priya. All rights reserved.
//

#import <UIKit/UIKit.h>
 

@interface RegisterViewController : UIViewController

 
 
- (IBAction)actionRegister:(id)sender;


@end
