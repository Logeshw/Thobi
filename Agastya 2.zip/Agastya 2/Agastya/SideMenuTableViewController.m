//
//  SideMenuTableViewController.m
//  Bharat_Electronics
//
//  Created by Priya on 08/03/16.
//  Copyright © 2016 Priya. All rights reserved.
//

#import "SideMenuTableViewController.h"
#import "SWRevealViewController.h"

@interface SideMenuTableViewController ()
{
    NSArray * arrayTitle;
    NSArray * arrTitleImage;
    NSArray * arrCategories;
    NSArray *arrCategoryImage;
    BOOL selectedIndexpath;
    
}
@end

@implementation SideMenuTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [UIApplication sharedApplication].statusBarHidden = YES;
    
    arrayTitle = [[NSArray alloc] initWithObjects:@"Home",@"Categories", @"Bag", @"Favourites",@"Notifications",@"Share",@"Contact us",@"Payment",@"Logout",  nil];
    
    
    arrCategoryImage = [[NSArray alloc] initWithObjects:@"home", @"favourite", @"bag", @"favourite", @"notification",@"sharing", @"contact_us",@"payment",@"logout", nil];
    
  
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 1) {
        
            return [arrayTitle count];
        }
        else
        return  1;

    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        static NSString *CellIdentifier = @"ImageCell";
        
        UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        
            return cell;
    }
    else
    {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
   
   // imgView.image = [UIImage imageNamed:[arrCategoryImage objectAtIndex:indexPath.row -1]];
    
    UILabel *lblProductName = (UILabel *)[cell viewWithTag:20];
    lblProductName.text = [arrayTitle objectAtIndex:indexPath.row];
        
    UIImageView *imgView = (UIImageView *)[cell viewWithTag:10];
    imgView.image = [UIImage imageNamed:[arrCategoryImage objectAtIndex:indexPath.row]];
        return cell;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 120;
    }
    else
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        [self performSegueWithIdentifier:@"toHome" sender:nil];
    }else if (indexPath.row == 1){
        [self performSegueWithIdentifier:@"toCategories" sender:nil];
    }
    else if (indexPath.row == 2){
        [self performSegueWithIdentifier:@"toMyOrder" sender:nil];
    }
    else if (indexPath.row == 3){
        [self performSegueWithIdentifier:@"toFavourite" sender:nil];
    }
    else if (indexPath.row == 4){
        [self performSegueWithIdentifier:@"toNotification" sender:nil];
    }
    else if (indexPath.row == 5){
        [self performSegueWithIdentifier:@"toShare" sender:nil];
    }
    else if (indexPath.row == 6){
        [self performSegueWithIdentifier:@"toContactus" sender:nil];
    }
    else{
        [self performSegueWithIdentifier:@"toPayment" sender:nil];
    }
    
       
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
           
        
       
}
- (IBAction)regBtn:(id)sender {
   [self performSegueWithIdentifier:@"toReg" sender:nil];
}
- (IBAction)logBtn:(id)sender {
     [self performSegueWithIdentifier:@"toLog" sender:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
