//
//  LocationViewController.m
//  Thobi
//
//  Created by Asaraa on 5/24/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import "LocationViewController.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@implementation LocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    mapView = [[MKMapView alloc]
               initWithFrame:CGRectMake(0,
                                        0,
                                        self.view.bounds.size.width,
                                        self.view.bounds.size.height)
               ];
    mapView.showsUserLocation = YES;
    mapView.mapType = MKMapTypeHybrid;
    mapView.delegate = self;
    [self.view addSubview:mapView];
    
}

- (void)mapView:(MKMapView *)aMapView didUpdateUserLocation:(MKUserLocation *)aUserLocation {
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    span.latitudeDelta = 25.2048;
    span.longitudeDelta = 55.2708;
    CLLocationCoordinate2D location;
    location.latitude = aUserLocation.coordinate.latitude;
    location.longitude = aUserLocation.coordinate.longitude;
    region.span = span;
    region.center = location;
    [aMapView setRegion:region animated:YES];
}
- (IBAction)homeBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toLocation = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toLocation animated:YES];
    
}

- (IBAction)myOrderBtn:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toMyorder = [story instantiateViewControllerWithIdentifier:@"MyOrderViewController"];
    [self.navigationController pushViewController:toMyorder animated:YES];
    
    
}
- (IBAction)favouriteBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toFavourite = [story instantiateViewControllerWithIdentifier:@"Favourite"];
    [self.navigationController pushViewController:toFavourite animated:YES];
    
}



- (IBAction)profileBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toProfile = [story instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    [self.navigationController pushViewController:toProfile animated:YES];
    
}


- (IBAction)backBtn:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];
}
 
@end
