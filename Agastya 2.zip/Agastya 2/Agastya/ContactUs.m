

//
//  ContactUs.m
//  Agastya
//
//  Created by Asaraa on 5/15/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import "ContactUs.h"

@implementation ContactUs


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
}

- (IBAction)backBtn:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];
}
@end
