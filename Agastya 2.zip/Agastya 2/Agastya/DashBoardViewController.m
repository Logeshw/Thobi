//
//  DashBoardViewController.m
//  Agastya
//
//  Created by Priya on 01/05/16.
//  Copyright © 2016 Priya. All rights reserved.
//

#import "DashBoardViewController.h"
#import "SWRevealViewController.h"
 

@interface DashBoardViewController ()<SWRevealViewControllerDelegate>
{
    NSArray *arrayTitles;
    NSArray *arrayTitles1;
    NSArray *arrCategoryImage;
    UILabel *lbl1;
    UILabel *lbl2;
}


@end

@implementation DashBoardViewController

@synthesize scrollView,pageControl;

-(void)scrollViewDidScroll:(UIScrollView *)sender {
    if (!pageControlBeingUsed) {
        // Switch the indicator when more than 50% of the previous/next page is visible
        CGFloat pageWidth = self.scrollView.frame.size.width;
        int page = floor((self.scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
        self.pageControl.currentPage = page;
    }
}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    pageControlBeingUsed = YES;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    pageControlBeingUsed = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    pageControlBeingUsed = YES;
    
    NSArray *images = [[NSArray alloc] initWithObjects:[UIImage imageNamed:@"banner.png"],[UIImage imageNamed:@"discover.png"],[UIImage imageNamed:@"essential.png" ], nil];
    
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * images.count, self.scrollView.frame.size.height);
    
    for (int i = 0; i < images.count; i++) {
        CGRect frame;
        frame.origin.x = self.scrollView.frame.size.width * i;
        frame.origin.y = 0;
        frame.size = self.scrollView.frame.size;
        UIImageView* imgView = [[UIImageView alloc] init];
        imgView.image = [images objectAtIndex:i];
        imgView.frame = frame;
        [scrollView addSubview:imgView];
    }
    
    self.pageControl.currentPage = 0;
    self.pageControl.numberOfPages = images.count;
    

    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    self.revealViewController.delegate = self;
    if ( revealViewController )
    {
       // self.revealViewController.rightViewRevealWidth = 150;
        [self.menuButton setTarget: self.revealViewController];
        [self.menuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    
    arrCategoryImage = [[NSArray alloc] initWithObjects:@"01", @"02", @"03", @"04",@"05",@"06",@"03", @"01", nil];
    
    arrayTitles = [[NSArray alloc] initWithObjects:@"9999/-", @"4999/-", @"5999/-", @"8999/-",@"9999/-", @"4999/-", @"5999/-", @"8999/-", nil];
    arrayTitles1 = [[NSArray alloc] initWithObjects:@"1500", @"3500", @"4500", @"6500", @"7500", @"2500", @"3500", @"5500", nil];
}

  


- (IBAction)changePage{
    // update the scroll view to the appropriate page
    CGRect frame;
    frame.origin.x = self.scrollView.frame.size.width * self.pageControl.currentPage;
    frame.origin.y = 0;
    frame.size = self.scrollView.frame.size;
    [self.scrollView scrollRectToVisible:frame animated:YES];
    pageControlBeingUsed = YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    
//    [super viewWillAppear:animated];
// 
//    UIView *viewForNavigationBar = (UIView *)[[NSBundle mainBundle] loadNibNamed:@"NavBar" owner:self options:nil][0];
//    [viewForNavigationBar setBackgroundColor:[UIColor blackColor]];
//    viewForNavigationBar.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 47);
//    lbl1= (UILabel *)[viewForNavigationBar viewWithTag:3];
//   ;
//    
//       self.navigationItem.titleView = viewForNavigationBar;
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationItem.title = @"";
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [arrayTitles count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    
    UIImageView *imgViewProduct = (UIImageView *)[cell viewWithTag:10];
    
    imgViewProduct.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@",arrCategoryImage[indexPath.row]]];
    
    UILabel *lblProductName = (UILabel *)[cell viewWithTag:20];
    lblProductName.text = [arrayTitles objectAtIndex:indexPath.row];
    
    UILabel *lblProductName1 = (UILabel *)[cell viewWithTag:30];
    lblProductName1.text = [arrayTitles1 objectAtIndex:indexPath.row];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0){
        
    }
    
    else{
        
          }
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // Adjust cell size for orientation
  
    NSLog(@"_collectionView.frame.size.height/2 = %f",_collectionView.frame.size.height);
    return CGSizeMake([UIScreen mainScreen].bounds.size.width/2 - 20, _collectionView.frame.size.height/2 - 20);

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
     
}


 
- (IBAction)actionPageControl:(id)sender {
}

- (IBAction)myOrderBtn:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toMyorder = [story instantiateViewControllerWithIdentifier:@"MyOrderViewController"];
    [self.navigationController pushViewController:toMyorder animated:YES];

 
}
- (IBAction)favouriteBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toFavourite = [story instantiateViewControllerWithIdentifier:@"Favourite"];
   [self.navigationController pushViewController:toFavourite animated:YES];

}

- (IBAction)locationBtn:(id)sender {
  
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toLocation = [story instantiateViewControllerWithIdentifier:@"LocationViewController"];
    [self.navigationController pushViewController:toLocation animated:YES];

}

- (IBAction)profileBtn:(id)sender {
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toProfile = [story instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    [self.navigationController pushViewController:toProfile animated:YES];

}


@end
