//
//  LocationViewController.h
//  Thobi
//
//  Created by Asaraa on 5/24/17.
//  Copyright © 2017 Priya. All rights reserved.
//

#import <UIKit/UIKit.h>
 
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface LocationViewController : UIViewController<UISplitViewControllerDelegate, MKMapViewDelegate> {
    MKMapView *mapView;
}
 

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@end
