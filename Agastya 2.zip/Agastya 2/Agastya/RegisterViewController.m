//
//  RegisterViewController.m
//  Agastya
//
//  Created by Dipin on 04/05/16.
//  Copyright © 2016 Priya. All rights reserved.
//

#import "RegisterViewController.h"

 

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
     

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (IBAction)actionRegister:(id)sender
{
   

}


- (IBAction)backBtn:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];

}

 

@end
