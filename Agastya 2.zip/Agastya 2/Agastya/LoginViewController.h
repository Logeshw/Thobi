//
//  LoginViewController.h
//  Agastya
//
//  Created by Priya on 23/04/16.
//  Copyright © 2016 Priya. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoginViewController : UIViewController

 
- (IBAction)actionRegister:(id)sender;
- (IBAction)actionLogin:(id)sender;


@end
