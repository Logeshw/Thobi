//
//  LoginViewController.m
//  Agastya
//
//  Created by Priya on 23/04/16.
//  Copyright © 2016 Priya. All rights reserved.
//

#import "LoginViewController.h"
 


@implementation LoginViewController

- (void)viewDidLoad {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (IBAction)actionRegister:(id)sender {
    [self performSegueWithIdentifier:@"toRegister" sender:nil];
}

- (IBAction)actionLogin:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];
    
}

- (IBAction)skipLogin:(id)sender {
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *toHome = [story instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:toHome animated:YES];
    
}




@end
